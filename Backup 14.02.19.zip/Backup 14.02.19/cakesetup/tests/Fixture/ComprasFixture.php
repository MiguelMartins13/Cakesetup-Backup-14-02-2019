<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ComprasFixture
 *
 */
class ComprasFixture extends TestFixture
{

    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_compra' => ['type' => 'integer', 'length' => 3, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'id_jogo' => ['type' => 'integer', 'length' => 3, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'id_forn' => ['type' => 'integer', 'length' => 3, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'data' => ['type' => 'date', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'hora' => ['type' => 'time', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'quant' => ['type' => 'integer', 'length' => 5, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        '_indexes' => [
            'id_jogo' => ['type' => 'index', 'columns' => ['id_jogo'], 'length' => []],
            'id_forn' => ['type' => 'index', 'columns' => ['id_forn'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_compra'], 'length' => []],
            'compras_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_jogo'], 'references' => ['jogos', 'id_jogo'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'compras_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_forn'], 'references' => ['fornecedores', 'id_forn'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd

    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_compra' => 1,
                'id_jogo' => 1,
                'id_forn' => 1,
                'data' => '2019-02-14',
                'hora' => '12:35:25',
                'quant' => 1
            ],
        ];
        parent::init();
    }
}
