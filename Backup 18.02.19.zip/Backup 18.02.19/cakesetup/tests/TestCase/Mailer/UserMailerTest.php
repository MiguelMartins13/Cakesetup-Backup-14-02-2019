<?php
namespace App\Test\TestCase\Mailer;

use App\Mailer\UserMailer;
use Cake\TestSuite\TestCase;

/**
 * App\Mailer\UserMailer Test Case
 */
class UserMailerTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Mailer\UserMailer
     */
    public $User;

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
