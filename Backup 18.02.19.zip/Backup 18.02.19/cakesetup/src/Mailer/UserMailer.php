<?php
namespace App\Mailer;

use Cake\Mailer\Mailer;

/**
 * User mailer.
 */
class UserMailer extends Mailer
{

    /**
     * Mailer's name.
     *
     * @var string
     */
    public static $name = 'User';
	
	public function welcome($user)
	{
		$this->to($user->email)
		->profile('teste')
		->emailFormat('html')
		->template('welcome_email_template')
		->layout('default')
		->viewVars(['nome' => $user->name])
		->subject(sprintf('Bem-vindo, %s', $user->name));
	}
}
