<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Jogos Model
 *
 * @method \App\Model\Entity\Jogo get($primaryKey, $options = [])
 * @method \App\Model\Entity\Jogo newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Jogo[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Jogo|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Jogo|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Jogo patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Jogo[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Jogo findOrCreate($search, callable $callback = null, $options = [])
 */
class JogosTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('jogos');
        $this->setDisplayField('id_jogo');
        $this->setPrimaryKey('id_jogo');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_jogo')
            ->allowEmptyString('id_jogo', 'create');

        $validator
            ->integer('id_categ')
            ->requirePresence('id_categ', 'create')
            ->allowEmptyString('id_categ', false);

        $validator
            ->scalar('nome')
            ->maxLength('nome', 100)
            ->requirePresence('nome', 'create')
            ->allowEmptyString('nome', false);

        $validator
            ->decimal('preco')
            ->requirePresence('preco', 'create')
            ->allowEmptyString('preco', false);

        $validator
            ->integer('pegi')
            ->requirePresence('pegi', 'create')
            ->allowEmptyString('pegi', false);

        $validator
            ->date('data_lanc')
            ->requirePresence('data_lanc', 'create')
            ->allowEmptyDate('data_lanc', false);

        $validator
            ->scalar('plataformas')
            ->maxLength('plataformas', 20)
            ->requirePresence('plataformas', 'create')
            ->allowEmptyString('plataformas', false);

        return $validator;
    }
}
